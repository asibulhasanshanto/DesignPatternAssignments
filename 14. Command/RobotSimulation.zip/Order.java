public interface Order {
    public void execute();
}
