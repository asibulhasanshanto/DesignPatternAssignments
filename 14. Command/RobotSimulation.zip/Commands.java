public class Commands{
    public void walkForward(){
        System.out.println("Walking forward..");
    }
    public void stop(){
        System.out.println("Stopped");
    }
    public void turnLeft(){
        System.out.println("Turned left");
    }
    public void turnRight(){
        System.out.println("Turned right");
    }
    public void goBackward(){
        System.out.println("Walking backward..");
    }

}